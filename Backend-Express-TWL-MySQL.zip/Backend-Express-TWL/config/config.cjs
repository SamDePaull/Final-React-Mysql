module.exports = {
    jwtSecretKey: 'secret-key',
    database: {
        host: 'localhost',
        username: 'root',
        password: '',
        database: 'upload_db',
        dialect: 'mysql'
    }
};
